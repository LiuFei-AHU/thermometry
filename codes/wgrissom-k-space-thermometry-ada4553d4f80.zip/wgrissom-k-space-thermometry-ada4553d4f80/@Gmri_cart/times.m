function ress = times(a,bb)

ress = mtimes(a,bb);
