function x = sqz(x)
x = squeeze(x);

